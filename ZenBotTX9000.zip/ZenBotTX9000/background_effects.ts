'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'

export function BackgroundEffects() {
  return (